

from datetime import date

from odoo import api, fields, models


class ResPartner(models.Model):
    _inherit = 'res.partner'

    def download_cust_statement(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/download/cust_statement/pdf/{self.id}',
            'target': 'blank',
        }

    def download_cust_statement(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_url',
            'url': f'/download/cust_statement/pdf/{self.id}',
            'target': 'self',
        }

    @api.model
    def get_customer_statement_data(self, partner_id):
        partner = self.browse(partner_id)

        all_invoices = self.env['account.move'].search([
            ('payment_state', '!=', 'paid'),
            ('state', '!=', 'cancel'),
            ('partner_id', '=', partner_id)
        ]) #.filtered(lambda x: (x.amount_residual != 0 and not x.line_ids.filtered(lambda l: l.reconciled)) or (x.move_type == 'entry' and x.origin_payment_id.is_reconciled is False))

        # invoices = all_invoices.filtered(lambda x: (x.amount_residual != 0 and not x.line_ids.filtered(lambda l: l.reconciled)))
        move_ids = all_invoices.mapped('id') 
        print('move_ids = ', move_ids)
        invoices = self.env['account.move.line'].search([
            ('move_id', 'in', move_ids),
            ('payment_id.is_reconciled', '=', False),
            ('amount_residual', '>', 0)
        ])
       
        # print('Move Ids = ', move_ids)
        # payments = self.env['account.payment'].search([('move_id', 'in', move_ids)])
        # move_ids = payments.mapped('move_id')
        # unique_move_ids = [p.id for p in payments]
        # print('unique_move_ids = ', unique_move_ids)
        # payment_invoices = self.env['account.move'].search([ ('id', 'in', unique_move_ids) ])
        # invoices = partner.invoice_ids.filtered(lambda x: (x.payment_state != 'paid' and (x.state != 'cancel') and x.amount_residual != 0 and not x.line_ids.filtered(lambda l: l.reconciled)))
        # payments = partner.invoice_ids.filtered(lambda x: (x.move_type == 'entry' and x.origin_payment_id.is_reconciled is False))

        print(f'Partner total_due = {partner.total_due}')
        print(f'total_overdue = {partner.total_overdue}')
        
        return {
            'company': self.env.user.company_id,
            'partner': partner,
            'invoices': invoices,
            'total_due': partner.total_due,
            'total_overdue': partner.total_overdue,
            'today': date.today()
        }
    
    @api.model
    def get_customer_statement_pdf(self, partner_id):
        data = self.get_customer_statement_data(partner_id)
        pdf_content, _  = self.env['ir.actions.report'].sudo()._render_qweb_pdf('custom_pdf_reports.report_customer_statement', [partner_id], data = data)

        return pdf_content


    