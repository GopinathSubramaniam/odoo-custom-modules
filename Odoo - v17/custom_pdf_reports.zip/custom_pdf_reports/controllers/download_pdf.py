from odoo import http
from odoo.http import request


class DownloadPDFController(http.Controller):

    @http.route('/download/cust_statement/pdf/<int:partner_id>', type='http', auth='public')
    def download_pdf(self, partner_id):
        pdf_content = request.env['res.partner'].get_customer_statement_pdf(partner_id)
        
        pdf_filename = f"Customer_Statement.pdf"
        return request.make_response(pdf_content, [
            ('Content-Type', 'application/pdf'),
            ('Content-Disposition', f'inline; filename={pdf_filename}')
        ])