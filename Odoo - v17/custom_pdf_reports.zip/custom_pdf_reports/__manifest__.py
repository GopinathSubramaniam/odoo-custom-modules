{
    'name': 'Custom PDF Reports',
    'version': '1.0',
    'summary': 'Odoo 18 PDF Reports',
    'depends': ['web', 'hr_skills', 'sale', 'contacts', 'custom_sale', 'account'],
    'data': [
        'views/customer_statement.xml',
        'views/res_partner.xml',
    ],
    'assets': {
        'web.report_assets_pdf': [
            'custom_pdf_reports/static/src/css/custom_styles.css',
        ],
    },
    'installable': True,
    'application': False,
}
