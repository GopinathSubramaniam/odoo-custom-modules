{
    'name': 'Custom WhatsApp',
    'version': '1.0',
    'summary': 'Odoo 18 WhatsApp API',
    'depends': ['base_setup', 'web', 'account', 'custom_pdf_reports', 'sale'],
    'data': [
        'views/account_template.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'custom_whatsapp/static/src/components/**/*'
        ]
    },
    'installable': True,
    'application': False,
}
