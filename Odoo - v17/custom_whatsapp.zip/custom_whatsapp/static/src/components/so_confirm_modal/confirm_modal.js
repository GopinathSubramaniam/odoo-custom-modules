/** @odoo-module */


import { Chatter } from "@mail/chatter/web_portal/chatter";
import { ConfirmationDialog } from "@web/core/confirmation_dialog/confirmation_dialog";
import { _t } from "@web/core/l10n/translation";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { patch } from "@web/core/utils/patch";

/* const ActiveComponentService = {
    activeComponent: null,

    setActiveComponent() {
        this.activeComponent = component;
    },

    getActiveComponent() {
        return this.activeComponent;
    },
}
registry.category("services").add("active_component_service", ActiveComponentService); */

patch(Chatter.prototype, {
    setup() {
        super.setup();
        this.action = useService("action");
        this.dialogService = useService("dialog");
        // console.log('before active_component_service');
        
        // this.activeComponentService = useService("active_component_service");
        // this.activeComponentService.setActiveComponent(this);
        // console.log('after setActiveComponent');
    },

    // Send PDF 
    sendWhatsAppMessage(threadModel = '', threadId = '') {
        console.log('threadModel = ', threadModel);
        console.log('threadId = ', threadId);

        threadModel = (this.props && this.props.threadModel) ? this.props.threadModel : 'account.move';
        threadId = (this.props && this.props.threadId) ? this.props.threadId : threadId;

        switch (threadModel) {
            case 'sale.order':
                this.sendWhatsApp(threadModel, threadId, _t('Are you sure that you want to send the Quotation PDF to the customer ?'), 'whatsapp_confirm_modal');
                break;
            case 'account.move':
                this.sendWhatsApp(threadModel, threadId, _t('Are you sure that you want to send the Invoice PDF to the customer ?'), 'whatsapp_confirm_modal');
                break;
            case 'res.partner':
                this.sendWhatsApp(threadModel, threadId, _t('Are you sure that you want to send the Customer Statement to the customer ?'), 'whatsapp_confirm_modal');
                break;
            default:
                break;
        }
    },
    sendWhatsApp(threadModel, threadId, msg, method_name) {
        this.dialogService.add(ConfirmationDialog, {
            body: msg,
            confirmClass: "btn-primary",
            confirmLabel: _t("Confirm"),
            confirm: () => {
                let context = { 'threadModel': threadModel, 'threadId': threadId }
                this.action.doActionButton({
                    type: 'object',
                    resModel: this.props.threadModel,
                    resId: this.props.threadId,
                    name: method_name,
                    context: context,
                });

            },
            cancelLabel: _t("Close"),
            cancel: () => { },
        });
    },

});



const callWhatsApp = (env, options) => {
    const activeComponentService = env.services.active_component_service;
    const activeComponent = activeComponentService.getActiveComponent();
    if (activeComponent) {
        activeComponent.sendWhatsAppMessage(options.threadModel, options.threadId);
    } else {
        console.error("No active component found.");
    }
};


// console.log('called =========== ');
// const activeComponent = env.services.active_component;
// console.log(activeComponent);
// activeComponent.sendWhatsAppMessage();



registry.category("actions").add("sendWhatsAppMessage", callWhatsApp);

// registry.category('components').add('Chatter', Chatter);