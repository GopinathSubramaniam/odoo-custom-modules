import base64
from datetime import datetime, timedelta

from odoo import api, models
from odoo.http import request


class AccountMove(models.Model):

    _inherit = 'account.move'

    def button_confirm_and_call_js(self):
        self.action_post()
        
        self.whatsapp_confirm_modal()
    

    @api.model
    def whatsapp_confirm_modal(self, *args):
        print('show_whatsapp_modal ::::::::::::::::::: ')

        threadModel = self.env.context.get('threadModel', 'account.move')
        threadId = self.env.context.get('threadId', self.id)
        
        print('Order ID = ', threadId)
        print('Order Name = ', threadModel)

        if threadId > 0:
            invoice = self.env['account.move'].browse(threadId)
            pdf_content, _ = self.env['ir.actions.report'].sudo()._render_qweb_pdf('account.report_invoice', [invoice.id])
            base64_data = base64.b64encode(pdf_content)
            base64_string = base64_data.decode('utf-8')

            msg = 'Your Invoice has been confirmed. Please check and contact us for more details.'
            return self.env['message.api'].send_msg_with_file(base64_string, msg, invoice.partner_id.mobile)


    # Call this method from Technical > Automations > Scheduled Actions > New 
    # Model = account.move (Journal Entry)
    # Execute Every = 1 Day
    # Paste this code in the "Code" area:- model.send_invoice_due_reminder()
    @api.model
    def send_invoice_due_reminder(self):
        # Get the current date
        today = datetime.today().date()
        
        # Get invoices where due date is tomorrow or overdue
        invoices_due = self.env['account.move'].search([
            # ('invoice_date_due', '=', today + timedelta(days=1)),
            ('payment_state', '!=', 'paid'),
            ('state', '!=', 'cancel'),
            ('amount_residual', '!=', 0),
            ('line_ids.reconciled', '!=', True)
        ])
        
        """ invoices_overdue = self.env['account.move'].search([
            ('invoice_date_due', '<', today),
            ('state', '=', 'posted'),
            ('move_type', '=', 'out_invoice')  # Only customer invoices
        ]) """
        
        # Combine due soon and overdue invoices
        # invoices_to_notify = invoices_due_soon | invoices_overdue

        grouped_totals  = {}
        for inv in invoices_due:
            customer = inv.partner_id
            print(customer)
            if customer not in grouped_totals :
                 grouped_totals[customer] = 0.0
            grouped_totals[customer] += inv.amount_residual
        
        result = [{ 'cust_name': cust.name, 'cust_mobile': cust.mobile, 'cust_id': cust.id, 'total_due': total_due, } for cust, total_due  in grouped_totals.items() ]

        print('::::::result = ', len(result))
        print('::::::str result = ', str(result))

        # Send email reminders
        for r in result:
            print('Mobile = ', str(r['cust_name']))
            if r['cust_mobile']:
                # Use the email template to send an email
                print('Message Sending....')
                pdf_content = self.env['res.partner'].get_customer_statement_pdf(r['cust_id'])
                # pdf_content, _ = self.env['ir.actions.report'].sudo()._render_qweb_pdf('account.report_invoice', [invoice.id])
                base64_data = base64.b64encode(pdf_content)
                base64_string = base64_data.decode('utf-8')

                msg = 'Seems you have Upcoming/Pending Payment in the list. '
                if r['total_due'] > 0:
                    msg += ('Your *Total Overdue is: %s*. ' % (r['total_due']))

                msg += 'Kindly check your attached statement and clear the payment as soon as possible.'
                self.env['message.api'].send_msg_with_file(base64_string, msg, r['cust_mobile'])

                print('Message Sent')