
import re
import requests
import random

from odoo import models


class MessageAPI(models.Model):
    _name = "message.api"
    _description = "Message API"

    BASE_URL = 'https://messagesapi.co.in'
    UID = '3tGNoE5R74fM0jrm2r9NOXENoMF2'
    DEVICE_NAME='oneplus'

    headers = { 'Content-Type': 'application/json' }

    # Get token to access other APIs
    def get_token(self):
        url = ('%s%s' % (self.BASE_URL, '/client/login'))
        try:
            payload = {
                "email":"oskarnoufal@gmail.com",
                "password":"Pawa1212"
            }
            response = requests.post(url, json=payload, headers=self.headers)
            if response.status_code == 200:
                data = response.json()
                return data
            else:
                return {}

        except Exception as e:
            return e
    
    def send_base64_file(self, file_base64, phone):
        print('send_base64_file ::::::::::::::::::::::')
        res = False
        try:
            url = self.BASE_URL + '/chat/sendBase64File'
            payload = {
                'id': self.UID,
                'name': self.DEVICE_NAME,
                'phone': phone,
                'base64File': {
                    'name': 'file_' + str(random.randint(10000000, 99999999)),
                    'body': file_base64
                }
            }
            
            response = requests.post(url, json=payload, headers=self.headers)
            if response.status_code == 200:
                response_json = response.json()
                print('Response ================ ')
                print(response_json)
                res = True

        except Exception as e:
            print('Error ::::::::::::::::::::::')
            print(e)
        
        return res
    
    def send_message(self, message, phone):
        res = False
        print('send_message ::::::::::::::::::::::')
        try:
            # data = self.get_token()
            # if data and data['uid']:
            url = self.BASE_URL + '/chat/sendMessage'
            payload = {
                'id': self.UID,
                'name': self.DEVICE_NAME,
                'message': message,
                'phone': phone,
            }
            response = requests.post(url, data=payload)
            print('Response Code = ', response.status_code)
            
            if response.status_code == 200:
                res = True
           
        except Exception as e:
            print(e)
        
        return  res 
    
    def send_msg_with_file(self, file_base64, message, phone):
        type = 'danger'
        msg = 'Message is not sent'

        if self.UID and self.DEVICE_NAME:
            phone = re.sub(r'[^0-9]', '', phone)
            # Sending file
            sent_file = self.send_base64_file(file_base64, phone)
            if sent_file:
                # Sending message
                sent_msg = self.send_message(message, phone)
                if sent_msg:
                    type = 'success'
                    msg = 'Message sent successfully'
        else:
            msg = 'Connect your device first'

        return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'type': type,
                    'title': 'Success',
                    'message': msg,
                    'sticky': False,
                }
            }

