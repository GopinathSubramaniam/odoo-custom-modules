import base64

from odoo import api, models
from .message_api import MessageAPI


class SaleOrder(models.Model):

    _inherit = 'sale.order'

    @api.model
    def whatsapp_confirm_modal(self, *args):
        print('show_whatsapp_modal ::::::::::::::::::: ')

        threadModel = self.env.context.get('threadModel', 'NIL')
        threadId = self.env.context.get('threadId', 0)
        
        print('Order ID = ', threadId)
        print('Order Name = ', threadModel)

        if threadId > 0:
            sale_order = self.env['sale.order'].browse(threadId)
            pdf_content, _ = self.env['ir.actions.report'].sudo()._render_qweb_pdf('sale.action_report_saleorder', [sale_order.id])
            base64_data = base64.b64encode(pdf_content)
            base64_string = base64_data.decode('utf-8')

            msg = 'Your quotation has been created. Please check and approve the quotation.'
            return self.env['message.api'].send_msg_with_file(base64_string, msg, sale_order.partner_id.mobile)