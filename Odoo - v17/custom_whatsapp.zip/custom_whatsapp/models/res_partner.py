import base64

from odoo import api, models
from odoo.http import request


class ResPartner(models.Model):
    
    _inherit = 'res.partner'

    @api.model
    def whatsapp_confirm_modal(self, *args):

        threadModel = self.env.context.get('threadModel', 'NIL')
        threadId = self.env.context.get('threadId', 0)
        
        if threadId > 0:
            partner = self.env['res.partner'].browse(threadId)
            
            data = self.get_customer_statement_data(partner.id)

            pdf_content, _  = self.env['ir.actions.report'].sudo()._render_qweb_pdf('custom_pdf_reports.report_customer_statement', [partner.id], data = data)
            base64_data = base64.b64encode(pdf_content)
            base64_string = base64_data.decode('utf-8')

            msg = 'Your may have outstanding invoices. Please check and pay the invoices.'
            return self.env['message.api'].send_msg_with_file(base64_string, msg, partner.mobile)