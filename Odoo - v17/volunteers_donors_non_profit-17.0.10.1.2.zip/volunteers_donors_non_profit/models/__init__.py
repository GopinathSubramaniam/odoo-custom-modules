# -*- coding: utf-8 -*-

from . import donor_type
from . import volunteer_skills
from . import volunteer_type
from . import res_partner
from . import crm_lead
from . import project_project
from . import volunteer_working_detail

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
