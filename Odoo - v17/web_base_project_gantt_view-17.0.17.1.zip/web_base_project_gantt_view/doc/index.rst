Project Gantt View / Gantt View for Project
============================================
-  This module provides  the Gantt View for Scheduling in Project Module.

Installation
========================
- Copy web_base_project_gantt_view module to addons folder
- Install the module normally like other modules.